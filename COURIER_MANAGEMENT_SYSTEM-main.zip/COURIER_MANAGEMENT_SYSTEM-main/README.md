# Courier-management-system-in-python

<img src="Screenshot (269).png" width='80%' height='380px'>
<br/>
<img src="Screenshot (270).png" width='80%' height='380px'>


<br/>
<img src="Screenshot (272).png" width='80%' height='380px'>
